/*
 * File:   ecu2_main.c
 * Author: Merin James
 *
 * Created on May 28, 2026, 9:54 AM
 */

#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "mkp.h"
#include "uart.h"
#include "clcd.h"

#define _XTAL_FREQ 20000000

static void init_config()
{
    ADCON1 = 0x0F;
    TRISB = 0x00; //LED config as o/p
    PORTB = 0x00;
    
    init_adc();
    init_matrix_keypad();
    init_can();
    init_clcd();
    init_uart();
    
}

int main()
{
    //call the functions
    init_config();

    while(1)
    {
        unsigned int rpm = get_rpm();

        unsigned char temp = get_engine_temp();

        IndicatorStatus ind_status = process_indicator();
        
        while(TXB0REQ);
        can_transmit(RPM_MSG_ID, rpm);
        __delay_ms(10);

        while(TXB0REQ);
        can_transmit(ENG_TEMP_MSG_ID, temp);
        __delay_ms(10);

        while(TXB0REQ);
        can_transmit(INDICATOR_MSG_ID, ind_status);
        __delay_ms(10);
        }
}

