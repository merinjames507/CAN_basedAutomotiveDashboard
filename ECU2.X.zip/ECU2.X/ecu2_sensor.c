/*
 * File:   ecu2_sensor.c
 * Author: Merin James
 *
 * Created on May 28, 2026, 9:54 AM
 */

#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "uart.h"
#include "mkp.h"


uint16_t get_rpm()
{
    //Implement the rpm function
    uint16_t adc_value = read_adc(CHANNEL4);
    
    return ((unsigned long)adc_value * 6000) / 1023;
}

uint16_t get_engine_temp()
{
    //Implement the engine temperature function
    
    uint16_t adc_val = read_adc(CHANNEL6);

    return ((unsigned long)adc_val * 100) / 1023;
}

IndicatorStatus process_indicator()
{
    unsigned char key = read_mkp(STATE_CHANGE);

    if(key == MK_SW1)
        return e_ind_left;
    
    else if(key == MK_SW2)
        return e_ind_right;
    
    else if(key == MK_SW3)
        return e_ind_hazard;
    
    else if(key == MK_SW4)
        return e_ind_off;

    return e_ind_off;
}
