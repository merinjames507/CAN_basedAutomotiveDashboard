/*
 * File:   euc1_main.c
 * Author: Merin James
 *
 * Created on May 26, 2026, 2:44 PM
 */

#include <xc.h>
#include "adc.h"
#include "matrix_kp.h"
#include "can.h"
#include "ecu1_sensor.h"
#include "clcd.h"
#include "msg_id.h"

char *gear_arr[] = {"N", "G1", "G2", "G3", "G4", "G5", "R", "CC"};

static void init_config()
{
    init_adc();
    init_matrix_keypad();
    init_can();
    init_clcd();
}
void main(void) 
{
    uint8_t data[1];
    
    init_config(); //adc, mkp, can
    
    while (1) 
    {
        unsigned int speed = get_speed();
        
        unsigned int gear = get_gear_pos();
        
        while(TXB0REQ);
        can_transmit(SPEED_MSG_ID, speed);
        __delay_ms(10);
        
        while(TXB0REQ);
        can_transmit(GEAR_MSG_ID, gear);
        __delay_ms(10);
        
    }
}
