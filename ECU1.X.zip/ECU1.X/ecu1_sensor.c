/*
 * File:   ecu1_sensor.c
 * Author: Merin James
 *
 * Created on May 26, 2026, 2:47 PM
 */

#include <xc.h>
#include "ecu1_sensor.h"
#include "matrix_kp.h"
#include "adc.h"
#include "can.h"
#include "clcd.h"
#include "msg_id.h"

unsigned char key, gear_pos = 0;

uint16_t get_speed()
{
    uint16_t adc_value = read_adc(CHANNEL4);  //0 - 1023
    
    return ((unsigned long)adc_value * 99) / 1023;
    
}

unsigned char get_gear_pos()
{
    //implement gear function
    key = read_mkp(STATE_CHANGE);
    
    if(key == MK_SW1)
    {
        if(gear_pos < 6)
            gear_pos++;
    }
    else if(key == MK_SW2)
    {
        if(gear_pos > 0)
            gear_pos--;
    }
    else if(key == MK_SW3)
    {
        gear_pos = 7;
    }
    
    return gear_pos;
}