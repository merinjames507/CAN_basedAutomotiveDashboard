#ifndef ECU1_SENSOR_H
#define ECU1_SENSOR_H

#include <stdint.h>

uint16_t get_speed(void);
unsigned char get_gear_pos();

#endif