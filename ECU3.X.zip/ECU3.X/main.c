/*
 * File:   main.c
 * Author: Merin James
 *
 * Created on June 10, 2026, 11:47 AM
 */

#include <xc.h>
#include <string.h>
#include "message_handler.h"
#include "msg_id.h"
#include "can.h"
#include "clcd.h"

unsigned int gear;
unsigned int speed;
unsigned int rpm;
unsigned int indicator;
unsigned char collision_active = 0;   // latch flag


void main(void)
{
    TRISB=0X00;
    PORTB =0X00;
    init_clcd();
    init_can();
    
    clcd_print("SPD G RPM  T  ID", LINE1(0));

    while (1)
    {
        if (can_receive())
        {
            unsigned int msg_id;
            msg_id = (((unsigned int) can_payload[SIDH] << 3) | (can_payload[SIDL]) >> 5);

            // --- Collision check ---
            if (msg_id == GEAR_MSG_ID)
            {
                gear = can_payload[D0];

                if ( gear == 7)   // collision condition
                {
                    collision_active = 1;     // latch ON
//                    gear = 7;                 // force gear to 0
                }

                if (!collision_active)
                    handle_gear_data(gear, 1);
                else
                    handle_gear_data(7, 1);   // stuck at 0
            }

            // --- Speed ---
            else if (msg_id == SPEED_MSG_ID)
            {
                speed = can_payload[D0];

                if (collision_active)
                    speed = 0;

                handle_speed_data(speed, 1);
            }

            // --- RPM ---
            else if (msg_id == RPM_MSG_ID)
            {
                rpm = ((unsigned int)(can_payload[D0] << 8) | can_payload[D1]);

                if (collision_active)
                    rpm = 0;

                handle_rpm_data(rpm, 2);
            }

            // --- Engine Temp (always updates) ---
            else if (msg_id == ENG_TEMP_MSG_ID)
            {
                handle_engine_temp_data(can_payload[D1], 1);
            }

            // --- Indicator ---
            else if (msg_id == INDICATOR_MSG_ID)
            {
                indicator = can_payload[D1];

                if (collision_active)
                {
                    indicator = e_ind_off;
                    handle_indicator_data(e_ind_off, 1);
                }
                else
                handle_indicator_data(indicator, 1);
            }
        }
    }
    return;
}