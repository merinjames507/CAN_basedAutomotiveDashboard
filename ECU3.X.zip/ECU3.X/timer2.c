/*
 * File:   timer2.c
 * Author: Merin James
 *
 * Created on June 11, 2026, 1:10 PM
 */
#include <xc.h>
#include "timer2.h"

void init_timer2()
{
    TMR2ON = 1;     //config for timer2
    TMR2IE = 1;
    TMR2IF = 0;
    PR2 = 249;
}