#ifndef TIMER2_H
#define TIMER2_H

extern unsigned int dutycycle;
extern unsigned int pwmcount;

void init_timer2(void);

#endif