#ifndef MESSAGE_HANDLER_H
#define	MESSAGE_HANDLER_H

#include <stdint.h>

#define LED_OFF 0
#define LED_ON 1

#define RIGHT_IND_ON()  (PORTBbits.RB7 = 1)
#define RIGHT_IND_OFF() (PORTBbits.RB7 = 0)
#define LEFT_IND_ON()   (PORTBbits.RB0 = 1)
#define LEFT_IND_OFF()  (PORTBbits.RB0 = 0)


extern volatile unsigned char led_state, status;

typedef enum {
    e_ind_off,
    e_ind_left,
    e_ind_right,
    e_ind_hazard
} IndicatorStatus;

void process_canbus_data();
void handle_speed_data(unsigned int data, unsigned int len);
void handle_gear_data(unsigned int data, unsigned int len);
void handle_rpm_data(unsigned int data, unsigned int len);
void handle_engine_temp_data(unsigned int data, unsigned int len);
void handle_indicator_data(unsigned int data, unsigned int len) ;

#endif	/* MESSAGE_HANDLER_H */
