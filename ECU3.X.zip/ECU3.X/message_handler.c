/*
 * File:   message_handler.c
 * Author: Merin James
 *
 * Created on June 10, 2026, 11:39 AM
 */

#include <xc.h>
#include <string.h>
#include "message_handler.h"
#include "msg_id.h"
#include "can.h"
#include "clcd.h"


volatile unsigned char led_state = LED_OFF, status = e_ind_off;
char gears_array[][2]={"N","1","2","3","4","5","R","C"};

void handle_speed_data(unsigned int data, unsigned int len)
{
    clcd_putch((data / 10) + '0', LINE2(0));
    clcd_putch((data % 10) + '0', LINE2(1));
        
}

void handle_gear_data(unsigned int data, unsigned int len) 
{
    
    clcd_print(gears_array[data], LINE2(4)); 
   
}

void handle_rpm_data(unsigned int data, unsigned int len) 
{
        clcd_putch(((data / 1000) % 10) + '0', LINE2(6)); // Thousands
        clcd_putch(((data / 100) % 10) + '0', LINE2(7));  // Hundreds
        clcd_putch(((data / 10) % 10) + '0', LINE2(8));   // Tens
        clcd_putch((data % 10) + '0', LINE2(9));
   
}

void handle_engine_temp_data(unsigned int data, unsigned int len) 
{ 
    clcd_putch((data/ 10) + '0', LINE2(11));
    clcd_putch((data% 10) + '0', LINE2(12));
}

void handle_indicator_data(unsigned int data, unsigned int len) 
{
    led_state = ((unsigned int) (data));

        if (led_state == e_ind_left)
        {
          clcd_putch('L', LINE2(14));
          PORTB=0X00;
          LEFT_IND_ON();
          
        }
        else if (led_state == e_ind_right)
        {
          clcd_putch('R', LINE2(14));
          PORTB=0X00;
          RIGHT_IND_ON();
        }
        else if (led_state == e_ind_hazard)
        {
          clcd_putch('H', LINE2(14));
          PORTB=0XFF;
        }
        
}